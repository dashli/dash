package com.calculator.dash;


public class Contact {
    String uname,pass;
    public void setUname(String uname)
    {
        this.uname = uname;
    }
    public String getUname(){
        return this.uname;
    }
    public void setPass(String pass){
        this.pass = pass;
    }
    public String getPass(){
        return this.pass;
    }
}
